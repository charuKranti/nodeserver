const express = require("express");
const server = express();
const bodyParser = require('body-parser');
//var cookieParser = require('cookie-parser');
var app = require('./app')
const port = 4546;
// support parsing of application/json type post data
server.use(bodyParser.json());
//support parsing of application/x-www-form-urlencoded post data
app.use(bodyParser.urlencoded({ extended: true }));
// this is for setting cookies
//server.use(cookieParser());
server.use('/api', app);
// define the home page route
server.get('/', function (req, res) {
  res.send("Please contact admin");
  //res.sendFile("D:/react/nodeserver/index.html");
  //res.redirect("http://localhost:3000")
});
server.listen(port,()=>console.log("Server is turned ON!"));

//api url=> http://localhost:3000/api/response